/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject10;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

/**
 *
 * @author SA
 */
public class ConfigurationDemo {
    
        public static void main(String[] args){
            // Hibernate settings equivalent to hibernate.cfg.xml's properties
            Properties prop= new Properties();

            prop.setProperty(Environment.DRIVER, "oracle.jdbc.OracleDriver");
            prop.setProperty(Environment.URL, "jdbc:oracle:thin:@localhost:1521:XE");
            prop.setProperty(Environment.USER, "user1");
            prop.setProperty(Environment.PASS, "pass");
            prop.setProperty(Environment.DIALECT, "org.hibernate.dialect.OracleDialect");
            
            Configuration cfg = new Configuration();
            cfg.addProperties(prop);
            
            
            
        }    
}
