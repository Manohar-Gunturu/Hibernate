/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject10;

import java.util.HashSet;
import java.util.Set;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author SA
 */
public class Main {
    
    public static void main(String[] args){
        
        Configuration cfg = new Configuration();
        //searches for hibernate.cfg.xml file and load all the properties to establish connection
        cfg.configure();
        //in recent versions creating sessionfactory using configuration file is depricated 
        SessionFactory sf = cfg.buildSessionFactory();
        Session session = sf.openSession();
        //for non select statements we have to start transaction
        Transaction tx = session.beginTransaction();
        Set<Orders> s = new HashSet<>();
        Customer c = new Customer(6, "Jhon", "jhon@gm.com", s);
        //session.save returns primary key value of record inserted
        int i = (Integer)session.save(c);
        //we also have persist method
        //persist method doesnt return value because it may not does the insertion operation immediately
        session.persist(c);
        
        
        //unless we say tx.commit() it is not permanenelty stored
        tx.commit();
        
        session.close();
        
        sf.close();
    }    
    
}
