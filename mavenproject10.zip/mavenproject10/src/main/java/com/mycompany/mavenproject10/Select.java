/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject10;

import java.util.HashSet;
import java.util.Set;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author SA
 */
public class Select {
    public static void main(String[] args){
        
        Configuration cfg = new Configuration();
        //searches for hibernate.cfg.xml file and load all the properties to establish connection
        cfg.configure();
        //in recent versions creating sessionfactory using configuration file is depricated 
        SessionFactory sf = cfg.buildSessionFactory();
        Session session = sf.openSession();
      
       
        Customer c = (Customer) session.get(Customer.class, 2);
        session.beginTransaction();
        c.setName("Tony");
        session.getTransaction().commit();
        System.out.println(" Name of Customer is "+c.getName());
       
        session.getTransaction().commit();          
        session.close();
        
        sf.close();
    }    
}
