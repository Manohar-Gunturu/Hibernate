/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.exp3;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author SA
 */
public class UpdateHQL {
    
        public static void main(String[] args){
           
            //previously we used to get the Customer object first and the delete it, it has 2 sql queries
            //HQL is better
        Configuration cfg = new Configuration();
        cfg.configure();
        SessionFactory sf = cfg.buildSessionFactory(); 
        Session session = sf.openSession();
        //
        //Query query=session.createQuery("update Customer c set email=:email where c.customerId=:id");
        // or 
        Query query=session.createQuery("update Customer set email=:email where customer_id=:id");
        query.setString("email", "noware@gmail.com");
        query.setInteger("id", 9);
        int modifications=query.executeUpdate();
        
        session.close();
        sf.close();
            
        }
    
    
}
