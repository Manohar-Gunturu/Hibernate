/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.exp3;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author SA
 */
public class Demo1 {
     public static void main(String[] args){
             
        Configuration cfg = new Configuration();
        cfg.configure();
        SessionFactory sf = cfg.buildSessionFactory(); 
        Session session = sf.openSession();
        
        Query query = session.createQuery("FROM Customer as c INNER JOIN c.orderses as o where o.itemName=:nm");
        query.setString("nm" , "Dell XPS");
        List<Object[]> tuples = (List<Object[]>) query.list();
       
        for(Object[] tuple : tuples) {
            Customer cust = (Customer) tuple[0];
            System.out.println(cust.getEmail());
            Orders order = (Orders) tuple[1];
            System.out.println(order.getItemName());
       } 
        
        session.close();
        sf.close();
        
      }
}
