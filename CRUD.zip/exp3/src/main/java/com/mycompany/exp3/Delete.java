/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.exp3;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author SA
 */
public class Delete {
    
    
            public static void main(String[] args){                
                Configuration cfg = new Configuration();
                cfg.configure();
                SessionFactory sf = cfg.buildSessionFactory(); 
                Session session = sf.openSession();
                //
                //Query query=session.createQuery("update Customer c set email=:email where c.customerId=:id");
                // or 
                Query query=session.createQuery("delete from Orders where order_id=:id");
                query.setInteger("id", 106);
                int modifications=query.executeUpdate();

                session.close();
                sf.close();                          
            }
    
}
