/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.exp3;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author SA
 */
public class Select {
    
    public static void main(String[] args){
             
        Configuration cfg = new Configuration();
        cfg.configure();
        SessionFactory sf = cfg.buildSessionFactory(); 
        Session session = sf.openSession();
        
        Set<Orders> s = new HashSet<>();
       
        List<Object[]> tuples = (List<Object[]>)session.createQuery("FROM Customer c INNER JOIN c.orderses ").list();
       
        for(Object[] tuple : tuples) {
            Customer cust = (Customer) tuple[0];
            Orders order = (Orders) tuple[1];
            System.out.println(order.getItemName());
       } 
        
        session.close();
        sf.close();
        
      }
    }
    
