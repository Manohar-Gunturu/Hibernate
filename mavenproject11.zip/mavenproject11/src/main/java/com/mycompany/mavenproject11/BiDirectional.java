/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject11;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author SA
 */
public class BiDirectional {
    
    public static void main(String[] args){
        
        Configuration cfg = new Configuration();
        //searches for hibernate.cfg.xml file and load all the properties to establish connection
        cfg.configure();
        //in recent versions creating sessionfactory using configuration file is depricated 
        SessionFactory sf = cfg.buildSessionFactory();
        Session session = sf.openSession();
        //for non select statements we have to start transaction
        Transaction tx = session.beginTransaction();
        Set<Orders> s = new HashSet<>();
        //relation here is bidirectional as Customer has Orders property
        //and Order has customer property
        Customer c = new Customer(6, "Jhon", "jhon@gm.com", s);
        Orders o1 = new Orders(100, c, "DELL XPS", new BigDecimal(1991) );
        Orders o2 = new Orders(101, c, "DELL Inspiron", new BigDecimal(1291) );
        s.add(o1);
        s.add(o2);
        
        /*
        //session.save returns primary key value of record inserted
        int i = (Integer)session.save(c);
        //we have to save o1 and o2 again
        i = (Integer)session.save(o1);
        i = (Integer)session.save(o2);
        */
        //unless we say tx.commit() it is not permanenelty stored
        tx.commit();
        
        List customers = session.createQuery("FROM Customer").list();
         for (Iterator iterator1 = 
                           customers.iterator(); iterator1.hasNext();){
             Customer current = (Customer) iterator1.next(); 
             Set orderss = current.getOrderses();
             //select query runs each time
            for (Iterator iterator2 = 
                         orderss.iterator(); iterator2.hasNext();){
                Orders o = (Orders) iterator2.next();
                System.out.println(o.getItemName());
            }
         }
        
        session.close();
        
        sf.close();
    }    
    
}
