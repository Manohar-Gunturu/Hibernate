/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject12;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author SA
 */
public class Main {
    
     public static void main(String[] args){                
                Configuration cfg = new Configuration();
                cfg.configure();
                SessionFactory sf = cfg.buildSessionFactory(); 
                Session session = sf.openSession();
                
                session.beginTransaction();
                
                Customer1 c = new Customer1(0, "Paul", "pa@gm.cm");
                Orders1 o = new Orders1(0, "Dell ", c, 344);
                c.setOrders1(o);
                session.save(c);                
                session.getTransaction().commit();

                session.close();
                sf.close();                          
            }
    
    
}
