/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.uni;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author SA
 */
public class Main {
    
    public static void main(String[] args){
         
        Configuration cg = new Configuration();
        cg.configure();
        SessionFactory sf = cg.buildSessionFactory();
        Session session = sf.openSession();
        Set<Orders> s = new HashSet<>();
        Transaction tx = session.beginTransaction();
        Orders o1 = new Orders(102, "HP Spectra", new BigDecimal(1991) );
        Orders o2 = new Orders(103,  "Lenova Yoga", new BigDecimal(1291) );
        s.add(o1);
        s.add(o2);
        Customer c = new Customer(7, "Yoga", "yoga@gm.com", s);
        session.save(c);
        tx.commit();
        session.close();
        sf.close();         
                
    }
    
}
